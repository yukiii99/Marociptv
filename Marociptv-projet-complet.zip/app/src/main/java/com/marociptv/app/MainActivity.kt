package com.marociptv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { MarociptvApp() }
 }
}

@Composable
fun MarociptvApp() {
 val bg = Color(0xFF0B0B12)
 val purple = Color(0xFF8B5CF6)
 val card = Color(0xFF191824)
 MaterialTheme(colorScheme = darkColorScheme(primary = purple, background = bg, surface = card)) {
  Surface(Modifier.fillMaxSize(), color = bg) {
   Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
     Icon(Icons.Default.Tv, null, tint = purple)
     Text(" Marociptv", color = Color.White, fontSize = 26.sp)
    }
    Text("Films, séries et télévision", color = Color.LightGray)
    Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(20.dp)).padding(18.dp)) {
     Text("Bienvenue sur Marociptv", color = Color.White, fontSize = 22.sp)
     Spacer(Modifier.height(8.dp))
     Text("Votre espace de divertissement", color = Color.LightGray)
     Spacer(Modifier.height(12.dp))
     Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = purple)) { Text("Découvrir") }
    }
    Text("Explorer", color = Color.White, fontSize = 20.sp)
    Feature(Icons.Default.Movie, "Films", "Découvrez votre catalogue", purple, card)
    Feature(Icons.Default.Tv, "Télévision", "Accédez à vos chaînes", purple, card)
    Feature(Icons.Default.Search, "Recherche", "Trouvez un contenu", purple, card)
    Spacer(Modifier.weight(1f))
    Row(Modifier.fillMaxWidth().background(card, RoundedCornerShape(16.dp)).padding(14.dp), horizontalArrangement = Arrangement.SpaceAround) {
     Icon(Icons.Default.Home, "Accueil", tint = purple)
     Icon(Icons.Default.Movie, "Films", tint = Color.LightGray)
     Icon(Icons.Default.Search, "Recherche", tint = Color.LightGray)
    }
    Text("Démo d'interface : ajoutez uniquement des sources de contenu autorisées.", color = Color.Gray, fontSize = 11.sp)
   }
  }
 }
}

@Composable
private fun Feature(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, purple: Color, card: Color) {
 Row(Modifier.fillMaxWidth().background(card, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
  Icon(icon, null, tint = purple)
  Column(Modifier.padding(start = 14.dp)) {
   Text(title, color = Color.White)
   Text(subtitle, color = Color.LightGray, fontSize = 13.sp)
  }
 }
}
